﻿using System;

namespace Domain
{
    public class Professor
    {
        public string Name { get; }

        public Professor(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException();

            this.Name = name;
        }
    }
}
