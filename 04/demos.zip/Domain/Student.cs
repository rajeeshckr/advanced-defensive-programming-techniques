﻿using System;
using System.Collections.Generic;

namespace Domain
{
    public abstract class Student
    {
        private IDictionary<Subject, Grade> Grades { get; } = new Dictionary<Subject, Grade>();

        private string name;

        public string Name
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentException();
                if (char.IsHighSurrogate(value[value.Length - 1]))
                    throw new ArgumentException();
                this.name = value;
            }
        }

        public Semester Enrolled { get; private set; }

        public Student(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException();
            if (char.IsHighSurrogate(name[name.Length - 1]))
                throw new ArgumentException();
            this.Name = name;
        }

        public string NameInitial =>
            this.Name.Substring(0, char.IsHighSurrogate(this.Name[0]) ? 2 : 1);

        public void AddGrade(Subject subject, Grade grade)
        {
            if (!Enum.IsDefined(typeof(Grade), grade))
                throw new ArgumentException();
            if (subject == null || !this.IsEnlistedFor(subject))
                throw new ArgumentException();
            if (this.Grades.ContainsKey(subject) &&
                this.Grades[subject] != Grade.F)
                throw new ArgumentException();

            this.Grades[subject] = grade;
        }

        private bool IsEnlistedFor(Subject subject) => true;

        public abstract bool CanEnroll(Semester semester);

        public void Enroll(Semester semester)
        {
            if (!this.CanEnroll(semester))
                throw new ArgumentException();
            this.Enrolled = semester;
        }

        public IExamApplication ApplyFor(Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (builder.CanBuild())
            {
                return builder.Build();
            }
            else
            {
                // Think of something
                throw new ArgumentException();
            }
        }

        public Func<IExamApplication> GetExamApplicationFactory(
                                Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (!builder.CanBuild())
            {
                throw new ArgumentException();
            }

            return builder.Build;
        }

        public bool HasPassedExam(Subject onSubject) => false;
    }
}
