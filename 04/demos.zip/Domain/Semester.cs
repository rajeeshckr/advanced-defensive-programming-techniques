﻿namespace Domain
{
    public class Semester
    {
        public Semester Predecessor { get; }

        public Semester(Semester predecessor)
        {
            this.Predecessor = predecessor;
        }
    }
}
