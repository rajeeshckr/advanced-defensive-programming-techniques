﻿namespace Domain
{
    public enum Grade
    {
        A,
        B,
        C,
        D,
        F
    }
}
