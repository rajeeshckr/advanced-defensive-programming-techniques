﻿using System;
using Domain.Data;
using Domain.Models;
using Domain.ViewModels;
using Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Domain.Utils;

namespace College.Controllers
{
    public class ProfessorsController : Controller
    {
        private IReadOnlyRepository<ProfessorViewModel> ReadOnlyRepository { get; } = ReadOnlyRepositories.CreateProfessorsRepository();
        private IRepository<Professor> Repository { get; } = Repositories.CreateProfessorsRepository();

        public ActionResult Index() =>
            View(this.ReadOnlyRepository.GetAll());

        public ActionResult Details(int id) =>
            this.ReadOnlyRepository
                .TryFind(id)
                .Map(View)
                .Reduce(() => View("Index", this.ReadOnlyRepository.GetAll()));

        public ActionResult Create() => View();

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                return FailIfInvalid(collection).Reduce(() => CreateProfessor(collection));
            }
            catch
            {
                ModelState.AddModelError(string.Empty, "Invalid personal name.");
                return View();
            }
        }

        private Option<ActionResult> FailIfInvalid(FormCollection collection) =>
            FailIfInvalidFirstName(collection["FirstName"]).Map(Option.Some<ActionResult>)
                .Reduce(() => FailIfInvalidMiddleNames(collection["MiddleNames"])).Map(Option.Some<ActionResult>)
                .Reduce(() => FailIfInvalidLastName(collection["LastName"]));

        private ActionResult CreateProfessor(FormCollection collection)
        {
            IEnumerable<string> lastNamePatterns = this.LoadLastNamePatterns();

            PersonalName name = new PersonalName(lastNamePatterns, collection["FirstName"], collection["MiddleNames"], collection["LastName"]);

            Professor professor = new Professor(name);
            this.Repository.Add(professor);
            this.Repository.SaveChanges();

            return RedirectToAction("Index");

        }

        private Option<ActionResult> FailIfInvalidFirstName(string value) =>
            this.FailIfNullOrEmpty(value, "FirstName", "First name cannot be empty");

        private Option<ActionResult> FailIfInvalidMiddleNames(string value) =>
            this.FailIfNull(value, "MiddleNames", "Middle names must be defined");

        private Option<ActionResult> FailIfInvalidLastName(string value) =>
            this.FailIfNullOrEmpty(value, "LastName", "Last name cannot be empty");

        private Option<ActionResult> FailIfNullOrEmpty(string value, string modelName, string error) =>
            FailIf(() => string.IsNullOrEmpty(value), modelName, error);

        private Option<ActionResult> FailIfNull(object value, string modelName, string error) =>
            FailIf(() => value == null, modelName, error);

        private Option<ActionResult> FailIf(Func<bool> failCondition, string modelName, string error)
        {
            if (failCondition())
            {
                ModelState.AddModelError(modelName, error);
                return Option.Some<ActionResult>(View("Create"));
            }
            return Option.None<ActionResult>();
        }

        private IEnumerable<string> LoadLastNamePatterns()
        {
            using (var repo = ReadOnlyRepositories.CreateLastNamePatternRepository())
                return repo.GetAll().OrderBy(pattern => pattern.Ordinal).Select(pattern => pattern.Value).ToList();
        }
    }
}
