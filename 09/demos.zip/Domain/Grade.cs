﻿namespace Domain
{
    public class Grade
    {
        private Grade(double numericEquivalent)
        {
            this.NumericEquivalent = numericEquivalent;
        }

        public double NumericEquivalent { get; }

        public static Grade A => new Grade(4);
        public static Grade B => new Grade(3);
        public static Grade C => new Grade(2);
        public static Grade D => new Grade(1);
        public static Grade F => new Grade(0);
    }
}
