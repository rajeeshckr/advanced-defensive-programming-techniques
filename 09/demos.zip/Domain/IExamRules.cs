﻿using System.Collections.Generic;
using Domain.Models;

namespace Domain
{
    public interface IExamRules
    {
        IEnumerable<IExamApplication> Filter(IEnumerable<Student> candidates, IExam exam);
        IEnumerable<Student> FilterNotEligible(IEnumerable<Student> candidates, IExam exam);
    }
}

