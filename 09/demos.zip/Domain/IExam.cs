﻿using Domain.Models;

namespace Domain
{
    public interface IExam
    {
        Subject OnSubject { get; }
        Professor AdministeredBy { get; }
        IExam Substitute(Professor administrator);
    }
}
