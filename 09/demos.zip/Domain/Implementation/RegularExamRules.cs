﻿using System;
using System.Collections.Generic;
using System.Linq;
using Domain.Models;

namespace Domain.Implementation
{
    public class RegularExamRules : IExamRules
    {

        private bool HasPassed(Student candidate, Subject subject) =>
            candidate.HasPassedExam(subject);

        private bool IsDomestic(Student candidate) =>
            candidate is RegularStudent;

        private bool HasEnrolled(Student candidate, Semester semester) =>
            candidate.Enrolled == semester;

        private bool CanApply(Student candidate, IExam exam) =>
            !this.HasPassed(candidate, exam.OnSubject) &&
            (!this.IsDomestic(candidate) || this.HasEnrolled(candidate, exam.OnSubject.TaughtDuring));

        public IEnumerable<IExamApplication> Filter(IEnumerable<Student> candidates, IExam exam)
        {
            if (candidates == null)
                throw new ArgumentNullException(nameof(candidates));
            if (candidates.Any(candidate => candidate == null))
                throw new ArgumentNullException();
            if (exam == null)
                throw new ArgumentNullException(nameof(exam));

            return
                candidates
                    .Where(candidate => this.CanApply(candidate, exam))
                    .Select(candidate =>
                        new ExamApplication(new Exam(exam.OnSubject, exam.AdministeredBy), candidate));
        }

        public IEnumerable<Student> FilterNotEligible(IEnumerable<Student> candidates, IExam exam)
        {
            if (candidates == null)
                throw new ArgumentNullException(nameof(candidates));
            if (candidates.Any(candidate => candidate == null))
                throw new ArgumentNullException();
            if (exam == null)
                throw new ArgumentNullException(nameof(exam));

            return candidates.Where(candidate => !this.CanApply(candidate, exam));
        }
    }
}

