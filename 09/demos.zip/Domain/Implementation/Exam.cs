﻿using System;
using Domain.Models;

namespace Domain.Implementation
{
    public class Exam : IExam
    {
        public Subject OnSubject { get; }
        public Professor AdministeredBy { get; }

        public Exam(Subject onSubject, Professor administeredBy)
        {
            if (onSubject == null)
                throw new ArgumentNullException(nameof(onSubject));
            if (administeredBy == null)
                throw new ArgumentNullException(nameof(administeredBy));

            this.OnSubject = onSubject;
            this.AdministeredBy = administeredBy;
        }

        public IExam Substitute(Professor administrator) =>
            new Exam(this.OnSubject, administrator);
    }
}
