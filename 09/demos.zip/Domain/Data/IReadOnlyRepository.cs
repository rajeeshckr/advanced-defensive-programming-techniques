﻿using System;
using System.Linq;
using Domain.Utils;

namespace Domain.Data
{
    public interface IReadOnlyRepository<TModel> : IDisposable
    {
        IQueryable<TModel> GetAll();
        Option<TModel> TryFind(int id);
    }
}
