﻿using System;
using System.Collections.Generic;

namespace Domain
{
    public static class DictionaryExtensions
    {
        public static void WithValue<TKey, TValue>(this IDictionary<TKey, TValue> dictionary,
            TKey key, Action<TValue> execute)
        {
            TValue value;
            if (dictionary.TryGetValue(key, out value))
            {
                execute(value);
            }
        }
    }
}
