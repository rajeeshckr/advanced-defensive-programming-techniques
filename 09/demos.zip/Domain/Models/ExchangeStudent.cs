﻿namespace Domain.Models
{
    public class ExchangeStudent : Student
    {
        public ExchangeStudent(PersonalName name) : base(name) { }

        public override bool CanEnroll(Semester semester) =>
            semester != null;
    }
}
