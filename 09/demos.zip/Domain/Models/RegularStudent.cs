﻿namespace Domain.Models
{
    public class RegularStudent : Student
    {
        public RegularStudent(PersonalName name) : base(name) { }

        public override bool CanEnroll(Semester semester) =>
            semester != null && semester.Predecessor == base.Enrolled;
    }
}
