﻿using System;
using System.Collections.Generic;
using System.Linq;
using Domain.Implementation;
using Domain.Utils;

namespace Domain.Models
{
    public abstract class Student
    {
        private Stack<IExamApplication> Exams { get; set; } = new Stack<IExamApplication>();

        public PersonalName Name { get; }

        public Option<Semester> Enrolled { get; private set; }

        public Student(PersonalName name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            this.Name = name;
            this.Enrolled = Option.None<Semester>();
        }

        private Option<IExamApplication> TryGetApplication(Subject onSubject) =>
            this.Exams.FirstOrNone(record => record.ForExam.OnSubject == onSubject);

        private Option<IExamApplication> TryGetAssignableApplication(Subject onSubject) =>
            this.TryGetApplication(onSubject).Where(NoGradeAssigned);

        private bool NoGradeAssigned(IExamApplication application) =>
            !application.Grade.AsEnumerable().Any();

        public bool CanAssignGrade(Subject onSubject) =>
            this.TryGetAssignableApplication(onSubject).AsEnumerable().Any();

        private IExamApplication GetAssignableApplication(Subject onSubject) =>
            this.TryGetAssignableApplication(onSubject).Reduce(() => throw new ArgumentException());

        private IExamApplication With(Grade grade, Subject onSubject) =>
            this.GetAssignableApplication(onSubject).With(grade);

        public void Assign(Grade grade, Subject onSubject) =>
            this.Exams.Push(this.With(grade, onSubject));

        private bool IsEnlistedFor(Subject subject) => true;

        public abstract bool CanEnroll(Semester semester);

        public void Enroll(Semester semester)
        {
            if (!this.CanEnroll(semester))
                throw new ArgumentException();
            this.Enrolled = Option.Some(semester);
        }

        public IExamApplication ApplyFor(Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (!builder.CanBuild())
            {
                throw new ArgumentException();
            }

            IExamApplication application = builder.Build();
            this.Exams.Push(application);
            return application;
        }

        public bool HasPassedExam(Subject onSubject) => false;
    }
}
