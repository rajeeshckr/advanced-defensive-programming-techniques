﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Domain
{
    public class Subject
    {
        public string Name { get; }
        public Semester TaughtDuring { get; }
        private IList<Student> EnlistedStudents { get; } = new List<Student>();

        private Professor TaughtBy { get; }
        private Professor AssistedBy { get; }

        public IExam CanAdministerExam(Professor professor) => new Implementation.Exam(this, professor);

        public Subject(string name, Semester taughtDuring, Professor taughtBy, Professor teachingAssistant)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException();
            if (taughtDuring == null)
                throw new ArgumentNullException(nameof(taughtDuring));
            if (taughtBy == null)
                throw new ArgumentNullException(nameof(taughtBy));
            if (teachingAssistant == null)
                throw new ArgumentNullException(nameof(teachingAssistant));

            this.Name = name;
            this.TaughtDuring = taughtDuring;
            this.TaughtBy = taughtBy;
            this.AssistedBy = teachingAssistant;
        }

        public void Enlist(Student student)
        {
            if (student == null)
                throw new ArgumentNullException(nameof(student));
            this.EnlistedStudents.Add(student);
        }
    }
}
