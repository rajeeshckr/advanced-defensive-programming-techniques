﻿namespace Domain.ViewModels
{
    public class SemesterViewModel
    {
        public int Id { get; set; }
        public string Label { get; set; }
        public int Ordinal { get; set; }
        public SemesterViewModel Predecessor { get; set; }
    }
}
