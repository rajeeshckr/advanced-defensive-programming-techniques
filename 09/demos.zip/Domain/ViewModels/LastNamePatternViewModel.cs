﻿namespace Domain.ViewModels
{
    public class LastNamePatternViewModel
    {
        public int Id { get; set; }
        public int Ordinal { get; set; }
        public string Value { get; set; }
    }
}
