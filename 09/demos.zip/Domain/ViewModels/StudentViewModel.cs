﻿namespace Domain.ViewModels
{
    public class StudentViewModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleNames { get; set; }
        public string LastName { get; set; }
        public SemesterViewModel EnrolledSemester { get; set; }
    }
}
