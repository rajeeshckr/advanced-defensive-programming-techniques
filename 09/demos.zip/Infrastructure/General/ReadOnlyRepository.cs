﻿using System;
using Domain.Data;
using System.Data.Entity;
using System.Linq;
using AutoMapper.QueryableExtensions;
using AutoMapper;
using Domain.Utils;

namespace Infrastructure.General
{
    class ReadOnlyRepository<TModel, TPersistence, TDbContext> : IReadOnlyRepository<TModel>
        where TPersistence : PersistentObject
        where TDbContext : DbContext
    {
        private TDbContext DbContext { get; }
        private Func<TDbContext, DbSet<TPersistence>> GetDbSet { get; }

        private IQueryable<TPersistence> RawNonTrackingQuery =>
            this.GetDbSet(this.DbContext).AsNoTracking<TPersistence>();

        private IQueryable<TPersistence> NonTrackingQuery =>
            this.IncludeTables(RawNonTrackingQuery);

        private IQueryable<TModel> NonTrackingModelQuery =>
            this.NonTrackingQuery.ProjectTo<TModel>();

        private Func<IQueryable<TPersistence>, IQueryable<TPersistence>> IncludeTables { get; }

        private Action EnsureNotDisposed { get; set; } = () => { };

        public ReadOnlyRepository(Func<TDbContext> dbContextFactory, Func<TDbContext, DbSet<TPersistence>> getDbSet)
            : this(dbContextFactory, getDbSet, query => query)
        {
        }

        public ReadOnlyRepository(Func<TDbContext> dbContextFactory, Func<TDbContext, DbSet<TPersistence>> getDbSet, string includeTables) :
            this(dbContextFactory, getDbSet, query => query.Include(includeTables))
        {
        }

        private ReadOnlyRepository(Func<TDbContext> dbContextFactory, Func<TDbContext, DbSet<TPersistence>> getDbSet,
            Func<IQueryable<TPersistence>, IQueryable<TPersistence>> includeTables)
        {
            this.DbContext = dbContextFactory();
            this.GetDbSet = getDbSet;
            this.IncludeTables = includeTables;
        }

        public IQueryable<TModel> GetAll()
        {
            this.EnsureNotDisposed();
            return this.NonTrackingModelQuery;
        }

        public Option<TModel> TryFind(int id)
        {
            this.EnsureNotDisposed();
            Option<TPersistence> persisted = this.NonTrackingQuery.Where(obj => obj.Id == id).SingleOrNone();
            Option<TModel> model = persisted.Map(Mapper.Map<TModel>);
            return model;
        }

        private bool IsDisposed { get; set; } = false;

        protected virtual void Dispose(bool disposing)
        {
            if (this.IsDisposed || !disposing)
                return;

            this.DbContext.Dispose();
            this.EnsureNotDisposed = () => { throw new ObjectDisposedException("read-only repository"); };
            IsDisposed = true;
        }

        ~ReadOnlyRepository()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
