﻿using System.ComponentModel.DataAnnotations;

namespace Infrastructure.General
{
    class PersistentObject
    {
        [Key]
        public int Id { get; set; }
    }
}
