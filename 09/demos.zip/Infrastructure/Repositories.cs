﻿using Domain.Data;
using Domain.Models;
using Infrastructure.Converters;
using Infrastructure.General;
using Infrastructure.Implementation;

namespace Infrastructure
{
    public static class Repositories
    {
        public static IRepository<Professor> CreateProfessorsRepository() =>
            new MappingRepository<Professor, Models.Professor, CollegeModel>(
                () => new CollegeModel(),
                new ProfessorConverter(),
                context => context.Professors);

        public static IRepository<Student> CreateStudentsRepository() =>
            new MappingRepository<Student, Models.Student, CollegeModel>(
                () => new CollegeModel(),
                new StudentConverter(CreateSemestersRepository(), new SemesterConverter()),
                context => context.Students);

        public static IRepository<Semester> CreateSemestersRepository() =>
            new SemesterRepository();
    }
}
