﻿using Infrastructure.General;

namespace Infrastructure.Models
{
    class Student : PersistentObject
    {
        public string FirstName { get; set; }
        public string MiddleNames { get; set; }
        public string LastName { get; set; }
        public Semester EnrolledSemester { get; set; }
    }
}
