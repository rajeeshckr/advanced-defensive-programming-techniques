namespace Infrastructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Student_EnrolledSemester : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Students", "EnrolledSemester_Id", c => c.Int());
            CreateIndex("dbo.Students", "EnrolledSemester_Id");
            AddForeignKey("dbo.Students", "EnrolledSemester_Id", "dbo.Semesters", "Id");

            Sql("UPDATE dbo.Students SET EnrolledSemester_Id = (SELECT MIN(Id) FROM dbo.Semesters WHERE Ordinal = 1)");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Students", "EnrolledSemester_Id", "dbo.Semesters");
            DropIndex("dbo.Students", new[] { "EnrolledSemester_Id" });
            DropColumn("dbo.Students", "EnrolledSemester_Id");
        }
    }
}
