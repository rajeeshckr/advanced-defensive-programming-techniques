namespace Infrastructure.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class Semester : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Semesters",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Label = c.String(),
                        Ordinal = c.Int(nullable: false),
                        Predecessor_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Semesters", t => t.Predecessor_Id)
                .Index(t => t.Predecessor_Id);

            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) VALUES ('I semester', 1, NULL)");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'II semester', 2, Id FROM dbo.Semesters WHERE Ordinal = 1");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'III semester', 3, Id FROM dbo.Semesters WHERE Ordinal = 2");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'IV semester', 4, Id FROM dbo.Semesters WHERE Ordinal = 3");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'V semester', 5, Id FROM dbo.Semesters WHERE Ordinal = 4");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'VI semester', 6, Id FROM dbo.Semesters WHERE Ordinal = 5");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'VII semester', 7, Id FROM dbo.Semesters WHERE Ordinal = 6");
            Sql("INSERT INTO dbo.Semesters(Label, Ordinal, Predecessor_Id) SELECT 'VIII semester', 8, Id FROM dbo.Semesters WHERE Ordinal = 7");
        }

        public override void Down()
        {
            DropForeignKey("dbo.Semesters", "Predecessor_Id", "dbo.Semesters");
            DropIndex("dbo.Semesters", new[] { "Predecessor_Id" });
            DropTable("dbo.Semesters");
        }
    }
}
