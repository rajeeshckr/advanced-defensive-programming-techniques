﻿using System;

namespace Domain
{
    public abstract class Student
    {
        public string Name { get; }
        public Semester Enrolled { get; private set; }

        public Student(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException();
            this.Name = name;
        }

        public abstract bool CanEnroll(Semester semester);

        public void Enroll(Semester semester)
        {
            if (!this.CanEnroll(semester))
                throw new ArgumentException();
            this.Enrolled = semester;
        }

        public IExamApplication ApplyFor(Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (builder.CanBuild())
            {
                return builder.Build();
            }
            else
            {
                // Think of something smarter
                throw new ArgumentException();
            }
        }

        public Func<IExamApplication> GetExamApplicationFacotry(
            Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (!builder.CanBuild())
            {
                throw new ArgumentException();
            }

            return builder.Build;
        }

        public bool HasPassedExam(Subject onSubject) => false;
    }
}
