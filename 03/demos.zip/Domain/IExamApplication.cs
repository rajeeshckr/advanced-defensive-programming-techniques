﻿namespace Domain
{
    public interface IExamApplication
    {
        Subject OnSubject { get; }
        Professor AdministeredBy { get; }
        Student TakenBy { get; }
    }
}
