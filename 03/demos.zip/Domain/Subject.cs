﻿using System;

namespace Domain
{
    public class Subject
    {
        public string Name { get; }
        public Semester TaughtDuring { get; }
        public Professor TaughtBy { get; }

        public Subject(string name, Semester taughtDuring, Professor taughtBy)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException();
            if (taughtDuring == null)
                throw new ArgumentNullException(nameof(taughtDuring));
            if (taughtBy == null)
                throw new ArgumentNullException(nameof(taughtBy));

            this.Name = name;
            this.TaughtDuring = taughtDuring;
            this.TaughtBy = taughtBy;
        }
    }
}
