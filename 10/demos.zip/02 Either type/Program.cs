﻿using System;
using System.IO;
using System.Net;

namespace Demo
{
    class Failed
    {
    }

    class NotFound : Failed { }

    class Moved : Failed
    {
        public Uri MovedTo { get; }
        public Moved(Uri movedTo)
        {
            this.MovedTo = movedTo;
        }
    }

    class Timeout : Failed { }

    class NetworkError : Failed { }

    class Resource
    {
        public string Data { get; }

        public Resource(string data)
        {
            this.Data = data;
        }
    }

    abstract class Either<TLeft, TRight>
    {
        public abstract Either<TNewLeft, TRight> 
            MapLeft<TNewLeft>(Func<TLeft, TNewLeft> mapping);

        public abstract Either<TLeft, TNewRight>
            MapRight<TNewRight>(Func<TRight, TNewRight> mapping);

        public abstract TLeft Reduce(Func<TRight, TLeft> mapping);
    }

    class Left<TLeft, TRight> : Either<TLeft, TRight>
    {
        TLeft Value { get; }

        public Left(TLeft value)
        {
            this.Value  = value;
        }

        public override Either<TNewLeft, TRight> MapLeft<TNewLeft>(
            Func<TLeft, TNewLeft> mapping) =>
            new Left<TNewLeft, TRight>(mapping(this.Value));

        public override Either<TLeft, TNewRight> MapRight<TNewRight>(
            Func<TRight, TNewRight> mapping) =>
            new Left<TLeft, TNewRight>(this.Value);

        public override TLeft Reduce(Func<TRight, TLeft> mapping) =>
            this.Value;
    }

    class Right<TLeft, TRight> : Either<TLeft, TRight>
    {
        TRight Value { get; }

        public Right(TRight value)
        {
            this.Value = value;
        }

        public override Either<TNewLeft, TRight> MapLeft<TNewLeft>(
            Func<TLeft, TNewLeft> mapping) =>
            new Right<TNewLeft, TRight>(this.Value);

        public override Either<TLeft, TNewRight> MapRight<TNewRight>(
            Func<TRight, TNewRight> mapping) =>
            new Right<TLeft, TNewRight>(mapping(this.Value));

        public override TLeft Reduce(Func<TRight, TLeft> mapping) =>
            mapping(this.Value);
    }

    class Program
    {
        static Either<Failed, Resource> Fetch(Uri address)
        {
            var request = WebRequest.Create(address);

            try
            {
                HttpWebResponse response = (HttpWebResponse) request.GetResponse();
                if (response.StatusCode == HttpStatusCode.NotFound)
                    return new Left<Failed, Resource>(new NotFound());

                if (response.StatusCode == HttpStatusCode.Redirect ||
                            response.StatusCode == HttpStatusCode.TemporaryRedirect)
                {
                    Uri redirectUri = new Uri(response.Headers[HttpResponseHeader.Location]);
                    return new Left<Failed, Resource>(new Moved(redirectUri));
                }

                if (response.StatusCode != HttpStatusCode.OK)
                    return new Left<Failed, Resource>(new Failed());

                Stream dataStream = response.GetResponseStream();
                string data = new StreamReader(dataStream).ReadToEnd();
                return new Right<Failed, Resource>(new Resource(data));

            }
            catch (WebException ex) when (ex.Status == WebExceptionStatus.Timeout)
            {
                return new Left<Failed, Resource>(new Timeout());
            }
            catch (WebException)
            {
                return new Left<Failed, Resource>(new NetworkError());
            }
        }

        static void Main(string[] args)
        {
            Uri address = new Uri("https://something.out.there");
            Either<Failed, Resource> result = Fetch(address);

            string report = result
                .MapLeft(failure => $"Error fetching resource - {failure}")
                .Reduce(resource => resource.Data);

            Console.WriteLine(report);
        }

        static void Log(string message) { }
    }
}
