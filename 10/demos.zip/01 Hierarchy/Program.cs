﻿using System;
using System.IO;
using System.Net;

namespace Demo
{
    interface IResourceProcessor
    {
        void OnSuccess(Action<string> process);
    }

    class Failed : IResourceProcessor
    {
        public virtual void OnSuccess(Action<string> process) { }
    }

    class NotFound : Failed { }

    class Moved : Failed
    {
        public Uri MovedTo { get; }
        public Moved(Uri movedTo)
        {
            this.MovedTo = movedTo;
        }
    }

    class Timeout : Failed { }

    class NetworkError : Failed { }

    class Success : IResourceProcessor
    {
        private string Data { get; }

        public Success(string data)
        {
            this.Data = data;
        }

        public void OnSuccess(Action<string> process) =>
            process(this.Data);
    }

    class Program
    {
        static IResourceProcessor Process(Uri address)
        {
            var request = WebRequest.Create(address);

            try
            {
                HttpWebResponse response = (HttpWebResponse) request.GetResponse();
                if (response.StatusCode == HttpStatusCode.NotFound)
                    return new NotFound();

                if (response.StatusCode == HttpStatusCode.Redirect ||
                            response.StatusCode == HttpStatusCode.TemporaryRedirect)
                {
                    Uri redirectUri = new Uri(response.Headers[HttpResponseHeader.Location]);
                    return new Moved(redirectUri);
                }

                if (response.StatusCode != HttpStatusCode.OK)
                    return new Failed();

                Stream dataStream = response.GetResponseStream();
                string data = new StreamReader(dataStream).ReadToEnd();
                return new Success(data);

            }
            catch (WebException ex) when (ex.Status == WebExceptionStatus.Timeout)
            {
                return new Timeout();
            }
            catch (WebException)
            {
                return new NetworkError();
            }
        }

        static void Process(string data)
        {
            
        }

        static void Main(string[] args)
        {
        }

        static void Log(string message) { }
    }
}
