﻿using System;

namespace Domain.Models
{
    public class PersonalName
    {
        public string FirstName { get;}
        public string MiddleNames { get; }
        public string LastName { get; }

        public PersonalName(string firstName, string middleNames, string lastName)
        {
            if (this.IsBadMandatoryPart(firstName) ||
                this.IsBadOptionalPart(middleNames) ||
                this.IsBadMandatoryPart(lastName))
                throw new ArgumentException();

            this.FirstName = firstName;
            this.MiddleNames = middleNames;
            this.LastName = lastName;
        }

        private bool IsBadOptionalPart(string part) =>
            part == null || (part.Length > 0 && char.IsHighSurrogate(part[part.Length - 1]));

        private bool IsBadMandatoryPart(string part) =>
            this.IsBadOptionalPart(part) || part == string.Empty;

        public override bool Equals(object obj) =>
            this.Equals(obj as PersonalName);

        private bool Equals(PersonalName other) =>
            other != null &&
            this.ArePartsEqual(this.FirstName, other.FirstName) &&
            this.ArePartsEqual(this.MiddleNames, other.MiddleNames) &&
            this.ArePartsEqual(this.LastName, other.LastName);

        public override int GetHashCode() =>
            this.FirstName.GetHashCode() ^
            this.MiddleNames.GetHashCode() ^
            this.LastName.GetHashCode();

        private bool ArePartsEqual(string part1, string part2) =>
            string.Compare(part1, part2, StringComparison.OrdinalIgnoreCase) == 0;
    }
}
