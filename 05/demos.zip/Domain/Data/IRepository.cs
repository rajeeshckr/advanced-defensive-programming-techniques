﻿using System;
using System.Collections.Generic;

namespace Domain.Data
{
    public interface IRepository<T> : IDisposable
    {
        IEnumerable<T> GetAll();
        T Find(int id);
        void Add(T obj);
        void Delete(T obj);
        void SaveChanges();
    }
}
