﻿using System;
using System.Collections.Generic;

namespace Domain.Data
{
    public interface IReadOnlyRepository<TModel> : IDisposable
    {
        IEnumerable<TModel> GetAll();
        TModel Find(int id);
    }
}
