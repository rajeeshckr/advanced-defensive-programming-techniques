﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Domain
{
    public abstract class Student
    {
        private IDictionary<Subject, Grade> Grades { get; } =
            new Dictionary<Subject, Grade>();

        public PersonalName Name { get; }

        public Semester Enrolled { get; private set; }

        public Student(PersonalName name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            this.Name = name;
        }

        public void AddGrade(Subject subject, Grade grade)
        {
            if (grade == null)
                throw new ArgumentNullException(nameof(grade));
            if (subject == null || !this.IsEnlistedFor(subject))
                throw new ArgumentException();
            if (this.Grades.ContainsKey(subject) && this.Grades[subject] != Grade.F)
                throw new ArgumentException();
            this.Grades[subject] = grade;
        }

        public double AverageGrade =>
            this.Grades.Values
                .Select(grade => grade.NumericEquivalent)
                .Where(value => value > 0)
                .Average();

        private bool IsEnlistedFor(Subject subject) => true;

        public abstract bool CanEnroll(Semester semester);

        public void Enroll(Semester semester)
        {
            if (!this.CanEnroll(semester))
                throw new ArgumentException();
            this.Enrolled = semester;
        }

        public IExamApplication ApplyFor(Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (builder.CanBuild())
            {
                return builder.Build();
            }
            else
            {
                // Think of something
                throw new ArgumentException();
            }
        }

        public Func<IExamApplication> GetExamApplicationFactory(Subject examOn, Professor administeredBy)
        {
            ExamApplicationBuilder builder = new ExamApplicationBuilder();
            builder.OnSubject(examOn);
            builder.AdministeredBy(administeredBy);
            builder.TakenBy(this);

            if (!builder.CanBuild())
            {
                throw new ArgumentException();
            }

            return builder.Build;
        }

        public bool HasPassedExam(Subject onSubject) => false;
    }
}
