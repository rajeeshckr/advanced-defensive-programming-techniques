﻿using Domain.Models;
using Infrastructure.General;

namespace Infrastructure.Converters
{
    class ProfessorConverter : IModelConverter<Professor, Models.Professor>
    {
        public void CopyChanges(Professor from, Models.Professor to)
        {
            to.FirstName = from.Name.FirstName;
            to.MiddleNames = from.Name.MiddleNames;
            to.LastName = from.Name.LastName;
        }

        public Professor ToModel(Models.Professor persisted) =>
            new Professor(new PersonalName(persisted.FirstName, persisted.MiddleNames, persisted.LastName));

        public Models.Professor ToPersisted(Professor model) =>
            new Models.Professor()
            {
                FirstName = model.Name.FirstName,
                MiddleNames = model.Name.MiddleNames,
                LastName = model.Name.LastName
            };
    }
}
