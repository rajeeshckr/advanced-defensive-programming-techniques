﻿using System;
using System.Collections.Generic;
using Domain.Data;
using System.Data.Entity;
using System.Linq;
using Infrastructure.Models;

namespace Infrastructure.General
{
    class ReadOnlyRepository<TModel, TPersistence, TDbContext> : IReadOnlyRepository<TModel>
        where TPersistence : PersistentObject
        where TDbContext : DbContext
    {
        private TDbContext DbContext { get; }
        private Func<TDbContext, DbSet<TPersistence>> GetDbSet { get; }
        private Func<TPersistence, TModel> Mapping { get; }

        private IQueryable<TPersistence> NonTrackingQuery => this.GetDbSet(this.DbContext).AsNoTracking<TPersistence>();

        private Action EnsureNotDisposed { get; set; } = () => { };

        public ReadOnlyRepository(Func<TDbContext> dbContextFactory, Func<TDbContext, DbSet<TPersistence>> getDbSet, Func<TPersistence, TModel> mapping)
        {
            this.DbContext = dbContextFactory();
            this.GetDbSet = getDbSet;
            this.Mapping = mapping;
        }

        public IEnumerable<TModel> GetAll()
        {
            this.EnsureNotDisposed();
            return this.NonTrackingQuery.ToList().Select(this.Mapping).ToList();
        }

        public TModel Find(int id)
        {
            this.EnsureNotDisposed();
            return this.NonTrackingQuery.Where(obj => obj.Id == id).Select(this.Mapping).Single();
        }

        private bool IsDisposed { get; set; } = false;

        protected virtual void Dispose(bool disposing)
        {
            if (this.IsDisposed || !disposing)
                return;

            this.DbContext.Dispose();
            this.EnsureNotDisposed = () => { throw new ObjectDisposedException("read-only repository"); };
            IsDisposed = true;
        }

        ~ReadOnlyRepository()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
