﻿using System;
using System.Collections.Generic;
using Domain.Data;
using System.Data.Entity;

namespace Infrastructure.General
{
    class MappingRepository<TModel, TPersistence, TDbContext> : IRepository<TModel> 
        where TPersistence : class 
        where TDbContext : DbContext
    {

        private TDbContext DbContext { get; }
        private IModelConverter<TModel, TPersistence> Converter { get; }
        private Func<TDbContext, DbSet<TPersistence>> GetDbSet { get; }

        private IDictionary<TModel, TPersistence> MaterializedObjects { get; }
        private DbSet<TPersistence> DbSet => this.GetDbSet(this.DbContext);


        private Action EnsureNotDisposed { get; set; } = () => { };

        public MappingRepository(Func<TDbContext> dbContextFactory, IModelConverter<TModel, TPersistence> converter, Func<TDbContext, DbSet<TPersistence>> getDbSet)
        {
            this.DbContext = dbContextFactory();
            this.Converter = converter;
            this.MaterializedObjects = new Dictionary<TModel, TPersistence>();
            this.GetDbSet = getDbSet;
        }

        public void Add(TModel obj)
        {
            this.EnsureNotDisposed();
            if (obj == null)
            {
                throw new ArgumentNullException();
            }

            TPersistence persisted = this.Converter.ToPersisted(obj);
            this.DbSet.Add(persisted);
            this.MaterializedObjects[obj] = persisted;
        }

        public void Delete(TModel obj)
        {
            this.EnsureNotDisposed();
            if (obj == null || !this.MaterializedObjects.ContainsKey(obj))
            {
                throw new ArgumentException();
            }

            TPersistence persisted = this.MaterializedObjects[obj];
            this.DbSet.Remove(persisted);
            this.MaterializedObjects.Remove(obj);
        }

        public TModel Find(int id)
        {
            this.EnsureNotDisposed();

            TPersistence persisted = this.DbSet.Find(id);
            TModel model = this.Converter.ToModel(persisted);
            this.MaterializedObjects[model] = persisted;

            return model;
        }

        public IEnumerable<TModel> GetAll()
        {
            this.EnsureNotDisposed();

            foreach (TPersistence persisted in this.DbSet)
            {
                TModel model = this.Converter.ToModel(persisted);
                this.MaterializedObjects[model] = persisted;
                yield return model;
            }
        }

        public void SaveChanges()
        {
            this.EnsureNotDisposed();

            foreach (KeyValuePair<TModel, TPersistence> pair in this.MaterializedObjects)
            {
                this.Converter.CopyChanges(pair.Key, pair.Value);
            }
            this.DbContext.SaveChanges();
        }

        private bool IsDisposed { get; set; } = false;

        protected virtual void Dispose(bool disposing)
        {
            if (IsDisposed || !disposing)
                return;

            this.DbContext.Dispose();
            this.EnsureNotDisposed = () => { throw new ObjectDisposedException("repository"); };
            IsDisposed = true;
        }

        ~MappingRepository()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
