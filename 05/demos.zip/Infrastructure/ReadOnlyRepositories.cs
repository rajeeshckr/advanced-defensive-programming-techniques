﻿using Domain.Data;
using Domain.ViewModels;
using Infrastructure.General;
using Infrastructure.Models;

namespace Infrastructure
{
    public static class ReadOnlyRepositories
    {
        public static IReadOnlyRepository<ProfessorViewModel> CreateProfessorsRepository() =>
            new ReadOnlyRepository<ProfessorViewModel, Professor, CollegeModel>(
                () => new CollegeModel(), 
                dbContext => dbContext.Professors, 
                professor => new ProfessorViewModel()
                {
                    Id = professor.Id,
                    FirstName = professor.FirstName,
                    MiddleNames = professor.MiddleNames,
                    LastName = professor.LastName
                });
    }
}
