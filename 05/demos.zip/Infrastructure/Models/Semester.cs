﻿namespace Infrastructure.Models
{
    class Semester
    {
        public int Id { get; set; }
        public string Label { get; set; }
        public int Ordinal { get; set; }
        public int PredecessorId { get; set; }
    }
}
