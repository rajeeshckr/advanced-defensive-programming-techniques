﻿using System.ComponentModel.DataAnnotations;

namespace Infrastructure.Models
{
    class Professor : PersistentObject
    {
        public string FirstName { get; set; }
        public string MiddleNames { get; set; }
        public string LastName { get; set; }
    }
}
