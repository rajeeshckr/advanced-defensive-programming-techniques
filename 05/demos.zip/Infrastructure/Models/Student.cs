﻿namespace Infrastructure.Models
{
    class Student
    {
        public int Id { get; set; }

    }
}
