﻿using Domain.Data;
using Domain.Models;
using Domain.ViewModels;
using Infrastructure;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace College.Controllers
{
    public class ProfessorsController : Controller
    {
        private IReadOnlyRepository<ProfessorViewModel> ReadOnlyRepository = ReadOnlyRepositories.CreateProfessorsRepository();
        private IRepository<Professor> Repository = Repositories.CreateProfessorsRepository();

        public ActionResult Index()
        {
            return View(this.ReadOnlyRepository.GetAll());
        }

        public ActionResult Details(int id)
        {
            return View(this.ReadOnlyRepository.Find(id));
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                string firstName = collection["FirstName"];
                string middleNames = collection["MiddleNames"];
                string lastName = collection["LastName"];

                if (string.IsNullOrEmpty(firstName))
                {
                    ModelState.AddModelError("FirstName", "First name cannot be empty");
                    return View("Create");
                }

                if (middleNames == null)
                {
                    ModelState.AddModelError("MiddleNames", "Middle names must be defined");
                    return View("Create");
                }

                if (string.IsNullOrEmpty(lastName))
                {
                    ModelState.AddModelError("LastName", "Last name cannot be empty");
                    return View("Create");
                }

                IEnumerable<string> lastNamePatterns = this.LoadLastNamePatterns();

                PersonalName name = new PersonalName(lastNamePatterns, firstName, middleNames, lastName);
                Professor prof = new Professor(name);
                this.Repository.Add(prof);
                this.Repository.SaveChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                ModelState.AddModelError((string)null, "Invalid personal name.");
                return View();
            }
        }

        private IEnumerable<string> LoadLastNamePatterns()
        {
            using (var repo = ReadOnlyRepositories.CreateLastNamePatternRepository())
                return repo.GetAll().OrderBy(pattern => pattern.Ordinal).Select(pattern => pattern.Value).ToList();
        }
    }
}
