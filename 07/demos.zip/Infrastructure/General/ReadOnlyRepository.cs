﻿using System;
using System.Collections.Generic;
using Domain.Data;
using System.Data.Entity;
using System.Linq;
using Infrastructure.Models;
using AutoMapper.QueryableExtensions;
using AutoMapper;

namespace Infrastructure.General
{
    class ReadOnlyRepository<TModel, TPersistence, TDbContext> : IReadOnlyRepository<TModel>
        where TPersistence : PersistentObject
        where TDbContext : DbContext
    {
        private TDbContext DbContext { get; }
        private Func<TDbContext, DbSet<TPersistence>> GetDbSet { get; }

        private IQueryable<TPersistence> NonTrackingQuery => 
            this.GetDbSet(this.DbContext).AsNoTracking<TPersistence>();

        private IQueryable<TModel> NonTrackingModelQuery =>
            this.NonTrackingQuery.ProjectTo<TModel>();

        private Action EnsureNotDisposed { get; set; } = () => { };

        public ReadOnlyRepository(Func<TDbContext> dbContextFactory, Func<TDbContext, DbSet<TPersistence>> getDbSet)
        {
            this.DbContext = dbContextFactory();
            this.GetDbSet = getDbSet;
        }

        public IQueryable<TModel> GetAll()
        {
            this.EnsureNotDisposed();
            return this.NonTrackingModelQuery;
        }

        public TModel Find(int id)
        {
            this.EnsureNotDisposed();
            TPersistence persisted = this.NonTrackingQuery.Where(obj => obj.Id == id).Single();
            TModel model = Mapper.Map<TModel>(persisted);
            return model;
        }

        private bool IsDisposed { get; set; } = false;

        protected virtual void Dispose(bool disposing)
        {
            if (this.IsDisposed || !disposing)
                return;

            this.DbContext.Dispose();
            this.EnsureNotDisposed = () => { throw new ObjectDisposedException("read-only repository"); };
            IsDisposed = true;
        }

        ~ReadOnlyRepository()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
