﻿using Domain.Models;
using Infrastructure.General;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Converters
{
    class ProfessorConverter : IModelConverter<Professor, Models.Professor>
    {
        private IEnumerable<string> LastNamePatterns
        {
            get
            {
                using (var repo = ReadOnlyRepositories.CreateLastNamePatternRepository())
                    return repo.GetAll().OrderBy(pattern => pattern.Ordinal).Select(pattern => pattern.Value).ToList();
            }
        }

        public void CopyChanges(Professor from, Models.Professor to)
        {
            to.FirstName = from.Name.FirstName;
            to.MiddleNames = from.Name.MiddleNames;
            to.LastName = from.Name.LastName;
            to.LastNameInitial = from.Name.LastNameInitial;
        }

        public Professor ToModel(Models.Professor persisted) =>
            new Professor(new PersonalName(this.LastNamePatterns, persisted.FirstName, persisted.MiddleNames, persisted.LastName));

        public Models.Professor ToPersisted(Professor model) =>
            new Models.Professor()
            {
                FirstName = model.Name.FirstName,
                MiddleNames = model.Name.MiddleNames,
                LastName = model.Name.LastName,
                LastNameInitial = model.Name.LastNameInitial
            };
    }
}
