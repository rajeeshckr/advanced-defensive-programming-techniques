﻿using Domain.Data;
using Domain.Models;
using Infrastructure.Converters;
using Infrastructure.General;
using System.Collections.Generic;

namespace Infrastructure
{
    public static class Repositories
    {
        public static IRepository<Professor> CreateProfessorsRepository() =>
            new MappingRepository<Professor, Models.Professor, CollegeModel>(
                () => new CollegeModel(),
                new ProfessorConverter(),
                context => context.Professors);
    }
}
