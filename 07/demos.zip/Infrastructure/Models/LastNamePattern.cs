﻿namespace Infrastructure.Models
{
    class LastNamePattern : PersistentObject
    {
        public int Ordinal { get; set; }
        public string Value { get; set; }
    }
}
