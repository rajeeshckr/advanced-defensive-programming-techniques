﻿using System.ComponentModel.DataAnnotations;

namespace Infrastructure.Models
{
    class PersistentObject
    {
        [Key]
        public int Id { get; set; }
    }
}
