namespace Infrastructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PersonalName_in_Professor : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Professors", "FirstName", c => c.String());
            AddColumn("dbo.Professors", "MiddleNames", c => c.String());
            AddColumn("dbo.Professors", "LastName", c => c.String());
            DropColumn("dbo.Professors", "Name");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Professors", "Name", c => c.String());
            DropColumn("dbo.Professors", "LastName");
            DropColumn("dbo.Professors", "MiddleNames");
            DropColumn("dbo.Professors", "FirstName");
        }
    }
}
