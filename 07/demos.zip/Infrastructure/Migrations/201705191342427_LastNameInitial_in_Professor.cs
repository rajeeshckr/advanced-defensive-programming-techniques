namespace Infrastructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LastNameInitial_in_Professor : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Professors", "LastNameInitial", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Professors", "LastNameInitial");
        }
    }
}
