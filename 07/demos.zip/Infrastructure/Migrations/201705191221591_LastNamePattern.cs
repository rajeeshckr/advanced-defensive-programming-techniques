namespace Infrastructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LastNamePattern : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.LastNamePatterns",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Value = c.String(),
                    })
                .PrimaryKey(t => t.Id);

            Sql(@"INSERT INTO dbo.LastNamePatterns(Value) VALUES ('^[Dd][aei] (?<letter>\w)')");
            Sql(@"INSERT INTO dbo.LastNamePatterns(Value) VALUES ('^O''(?<letter>\w)')");
            Sql(@"INSERT INTO dbo.LastNamePatterns(Value) VALUES ('^[Ll]e (?<letter>\w)')");
        }

        public override void Down()
        {
            DropTable("dbo.LastNamePatterns");
        }
    }
}
