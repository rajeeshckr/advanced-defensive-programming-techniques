namespace Infrastructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LastNamePattern_Ordinal : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.LastNamePatterns", "Ordinal", c => c.Int(nullable: false));

            Sql(@"UPDATE dbo.LastNamePatterns SET Ordinal = Id");
        }
        
        public override void Down()
        {
            DropColumn("dbo.LastNamePatterns", "Ordinal");
        }
    }
}
