﻿using AutoMapper;
using Domain.Data;
using Domain.ViewModels;
using Infrastructure.General;
using Infrastructure.Models;

namespace Infrastructure
{
    public static class ReadOnlyRepositories
    {
        static ReadOnlyRepositories()
        {
            Mapper.Initialize(SetupMapping);
        }

        private static void SetupMapping(IMapperConfigurationExpression configuration)
        {
            configuration.CreateMap<Models.Professor, Domain.ViewModels.ProfessorViewModel>();
            configuration.CreateMap<Models.LastNamePattern, Domain.ViewModels.LastNamePatternViewModel>();
        }

        public static IReadOnlyRepository<ProfessorViewModel> CreateProfessorsRepository() =>
            new ReadOnlyRepository<ProfessorViewModel, Professor, CollegeModel>(
                () => new CollegeModel(), dbContext => dbContext.Professors);

        public static IReadOnlyRepository<LastNamePatternViewModel> CreateLastNamePatternRepository() =>
            new ReadOnlyRepository<LastNamePatternViewModel, LastNamePattern, CollegeModel>(
                () => new CollegeModel(), dbContext => dbContext.LastNamePatterns);
    }
}
