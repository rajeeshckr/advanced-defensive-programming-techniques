using Infrastructure.Models;
using System.Data.Entity;

namespace Infrastructure
{
    class CollegeModel : DbContext
    {
        public CollegeModel() : base("name=CollegeModel")
        {
        }

        public virtual DbSet<Professor> Professors { get; set; }

        public virtual DbSet<LastNamePattern> LastNamePatterns { get; set; }
    }
}