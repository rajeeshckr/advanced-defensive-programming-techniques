﻿using Domain.Models;
using System;

namespace Domain.Implementation
{
    public class ExamApplication : IExamApplication
    {
        public Subject OnSubject { get; }
        public Professor AdministeredBy { get; }
        public Student TakenBy { get; }

        public ExamApplication(Subject onSubject, Professor administrator, Student candidate)
        {
            this.OnSubject = onSubject;
            this.AdministeredBy = administrator;
            this.TakenBy = candidate;
        }
    }
}
