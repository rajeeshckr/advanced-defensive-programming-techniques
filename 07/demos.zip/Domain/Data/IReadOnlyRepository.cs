﻿using System;
using System.Linq;

namespace Domain.Data
{
    public interface IReadOnlyRepository<TModel> : IDisposable
    {
        IQueryable<TModel> GetAll();
        TModel Find(int id);
    }
}
