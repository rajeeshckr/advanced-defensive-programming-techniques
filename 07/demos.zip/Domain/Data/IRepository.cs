﻿using System;
using System.Collections.Generic;

namespace Domain.Data
{
    public interface IRepository<T> : IDisposable
    {
        T Find(int id);
        void Add(T obj);
        void Delete(T obj);
        void SaveChanges();
    }
}
