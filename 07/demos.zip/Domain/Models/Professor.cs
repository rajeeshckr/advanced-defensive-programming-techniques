﻿using System;

namespace Domain.Models
{
    public class Professor
    {
        public PersonalName Name { get; }

        public Professor(PersonalName name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            this.Name = name;
        }
    }
}
