﻿using AutoMapper;
using Domain.Data;
using Domain.ViewModels;
using Infrastructure.General;
using Infrastructure.Models;

namespace Infrastructure
{
    public static class ReadOnlyRepositories
    {
        static ReadOnlyRepositories()
        {
            Mapper.Initialize(SetupMapping);
        }

        private static void SetupMapping(IMapperConfigurationExpression configuration)
        {
            configuration.CreateMap<Models.Professor, Domain.ViewModels.ProfessorViewModel>();
            configuration.CreateMap<Models.LastNamePattern, Domain.ViewModels.LastNamePatternViewModel>();
            configuration.CreateMap<Models.Semester, Domain.ViewModels.SemesterViewModel>();
            configuration.CreateMap<Models.Student, Domain.ViewModels.StudentViewModel>();
        }

        public static IReadOnlyRepository<ProfessorViewModel> CreateProfessorsRepository() =>
            new ReadOnlyRepository<ProfessorViewModel, Professor, CollegeModel>(
                () => new CollegeModel(), dbContext => dbContext.Professors);

        public static IReadOnlyRepository<LastNamePatternViewModel> CreateLastNamePatternRepository() =>
            new ReadOnlyRepository<LastNamePatternViewModel, LastNamePattern, CollegeModel>(
                () => new CollegeModel(), dbContext => dbContext.LastNamePatterns);

        public static IReadOnlyRepository<SemesterViewModel> CreateSemesterRepository() =>
            new ReadOnlyRepository<SemesterViewModel, Semester, CollegeModel>(
                () => new CollegeModel(), dbContext => dbContext.Semesters, "Predecessor");

        public static IReadOnlyRepository<StudentViewModel> CreateStudentRepository() =>
            new ReadOnlyRepository<StudentViewModel, Student, CollegeModel>(
                () => new CollegeModel(), dbContext => dbContext.Students, "EnrolledSemester");
    }
}
