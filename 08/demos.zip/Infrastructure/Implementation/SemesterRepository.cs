﻿using System.Collections.Generic;
using Domain.Data;
using Domain.Models;
using Domain.Utils;
using Infrastructure.Converters;
using Infrastructure.General;
using System.Linq;

namespace Infrastructure.Implementation
{
    class SemesterRepository : IRepository<Semester>
    {
        private CollegeModel DbContext { get; } = new CollegeModel();
        private IModelConverter<Semester, Models.Semester> Converter { get; } = new SemesterConverter();
        private IDictionary<Semester, Models.Semester> ObjectMap { get; } = new Dictionary<Semester, Models.Semester>();
        private IDictionary<int, Semester> IdMap { get; } = new Dictionary<int, Semester>();

        public Option<Semester> TryFind(int id) =>
            this.IdMap.TryGetValue(id)
                .Map(Option.Some)
                .Reduce(() => this.Load(id).Map(this.ConvertAndMap));

        private Semester ConvertAndMap(Models.Semester persisted)
        {
            Semester model = this.Converter.ToModel(persisted);
            this.ObjectMap[model] = persisted;
            return model;
        }

        private Option<Models.Semester> Load(int id) =>
            this.DbContext.Semesters
                .Include("Predecessor")
                .OrderBy(semester => semester.Ordinal)      // Must order so that Predecessor is filled in all objects
                .ToList()
                .Where(semester => semester.Id == id)
                .FirstOrNone();

        public void Add(Semester obj)
        {
            Models.Semester persisted = this.Converter.ToPersisted(obj);
            this.ObjectMap[obj] = persisted;
            this.DbContext.Semesters.Add(persisted);
        }

        public void Delete(Semester obj)
        {
            Models.Semester persisted = this.ObjectMap[obj];
            this.DbContext.Semesters.Remove(persisted);
            this.ObjectMap.Remove(obj);

            if (persisted.Id > 0)
                this.IdMap.Remove(persisted.Id);
        }

        public void SaveChanges()
        {
            this.DbContext.SaveChanges();
        }

        public void Dispose()
        {
            DbContext?.Dispose();
        }
    }
}
