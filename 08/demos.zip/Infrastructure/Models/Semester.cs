﻿using Infrastructure.General;

namespace Infrastructure.Models
{
    class Semester : PersistentObject
    {
        public string Label { get; set; }
        public int Ordinal { get; set; }
        public Semester Predecessor { get; set; }
    }
}