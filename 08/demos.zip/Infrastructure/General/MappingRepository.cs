﻿using System;
using System.Collections.Generic;
using Domain.Data;
using System.Data.Entity;
using Domain.Utils;

namespace Infrastructure.General
{
    class MappingRepository<TModel, TPersistence, TDbContext> : IRepository<TModel> 
        where TPersistence : PersistentObject 
        where TDbContext : DbContext
    {

        private TDbContext DbContext { get; }
        private IModelConverter<TModel, TPersistence> Converter { get; }
        private Func<TDbContext, DbSet<TPersistence>> GetDbSet { get; }

        private IDictionary<TModel, TPersistence> MaterializedObjects { get; }
        private IDictionary<int, TModel> MaterializedIds { get; }
        private DbSet<TPersistence> DbSet => this.GetDbSet(this.DbContext);

        private Action EnsureNotDisposed { get; set; } = () => { };

        public MappingRepository(Func<TDbContext> dbContextFactory, IModelConverter<TModel, TPersistence> converter, Func<TDbContext, DbSet<TPersistence>> getDbSet)
        {
            this.DbContext = dbContextFactory();
            this.Converter = converter;
            this.MaterializedObjects = new Dictionary<TModel, TPersistence>();
            this.MaterializedIds = new Dictionary<int, TModel>();
            this.GetDbSet = getDbSet;
        }

        public void Add(TModel obj)
        {
            this.EnsureNotDisposed();
            if (obj == null)
            {
                throw new ArgumentNullException();
            }

            TPersistence persisted = this.Converter.ToPersisted(obj);
            this.DbSet.Add(persisted);
            this.MaterializedObjects[obj] = persisted;
        }

        public void Delete(TModel obj)
        {
            this.EnsureNotDisposed();
            if (obj == null || !this.MaterializedObjects.ContainsKey(obj))
            {
                throw new ArgumentException();
            }

            TPersistence persisted = this.MaterializedObjects[obj];
            this.DbSet.Remove(persisted);
            this.MaterializedObjects.Remove(obj);
        }

        public Option<TModel> TryFind(int id)
        {
            this.EnsureNotDisposed();

            TModel model;
            if (this.MaterializedIds.TryGetValue(id, out model))
                return Option.Some(model);

            TPersistence persisted = this.DbSet.Find(id);

            if (persisted == null)
                return Option.None<TModel>();

            model = this.Converter.ToModel(persisted);
            this.MaterializedObjects[model] = persisted;
            this.MaterializedIds[id] = model;

            return Option.Some(model);
        }

        public void SaveChanges()
        {
            this.EnsureNotDisposed();

            foreach (KeyValuePair<TModel, TPersistence> pair in this.MaterializedObjects)
            {
                this.Converter.CopyChanges(pair.Key, pair.Value);
            }
            this.DbContext.SaveChanges();

            foreach (KeyValuePair<TModel, TPersistence> pair in this.MaterializedObjects)
            {
                int id = pair.Value.Id;
                this.MaterializedIds[id] = pair.Key;
            }
        }

        private bool IsDisposed { get; set; } = false;

        protected virtual void Dispose(bool disposing)
        {
            if (IsDisposed || !disposing)
                return;

            this.DbContext.Dispose();
            this.EnsureNotDisposed = () => { throw new ObjectDisposedException("repository"); };
            IsDisposed = true;
        }

        ~MappingRepository()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
