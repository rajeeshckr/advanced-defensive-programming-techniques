﻿using Domain.Models;
using Infrastructure.General;

namespace Infrastructure.Converters
{
    class SemesterConverter : IModelConverter<Domain.Models.Semester, Models.Semester>
    {
        public Semester ToModel(Models.Semester persisted) =>
            persisted.Predecessor == null
                ? new Semester(persisted.Label, persisted.Ordinal)
                : new Semester(this.ToModel(persisted.Predecessor), persisted.Label, persisted.Ordinal);

        public Models.Semester ToPersisted(Semester model) =>
            new Models.Semester()
            {
                Label = model.Label,
                Ordinal = model.Ordinal,
                Predecessor = model.Predecessor.Map(this.ToPersisted).Reduce((Models.Semester)null)
            };

        public void CopyChanges(Semester from, Models.Semester to)
        {
            to.Label = from.Label;
            to.Ordinal = from.Ordinal;
            to.Predecessor = from.Predecessor.Map(this.ToPersisted).Reduce((Models.Semester)null);
        }
    }
}
