﻿using System.Collections.Generic;
using System.Linq;
using Domain.Data;
using Domain.Models;
using Domain.Utils;
using Infrastructure.General;

namespace Infrastructure.Converters
{
    class StudentConverter : IModelConverter<Student, Models.Student>
    {
        private IRepository<Semester> SemestersRepository { get; }
        private IModelConverter<Semester, Models.Semester> SemesterConverter { get; }

        public StudentConverter(IRepository<Semester> semestersRepository, IModelConverter<Semester, Models.Semester> semesterConverter)
        {
            this.SemestersRepository = semestersRepository;
            this.SemesterConverter = semesterConverter;
        }

        private IEnumerable<string> LastNamePatterns
        {
            get
            {
                using (var repo = ReadOnlyRepositories.CreateLastNamePatternRepository())
                    return repo.GetAll().OrderBy(pattern => pattern.Ordinal).Select(pattern => pattern.Value).ToList();
            }
        }

        public Student ToModel(Models.Student persisted)
        {
            PersonalName name = new PersonalName(this.LastNamePatterns, 
                persisted.FirstName, persisted.MiddleNames, persisted.LastName);

            Student student = new RegularStudent(name);

            foreach (Semester semester in this.GetSemesterHistory(persisted.EnrolledSemester))
                student.Enroll(semester);

            return student;
        }

        private IEnumerable<Semester> GetSemesterHistory(Models.Semester enrolled) =>
            this.GetSemesterHistory(enrolled == null ? Option.None<Models.Semester>() : Option.Some(enrolled));

        private IEnumerable<Semester> GetSemesterHistory(Option<Models.Semester> enrolled) =>
            enrolled
                .Map(semester => this.SemestersRepository.TryFind(semester.Id))
                .Reduce(Option.None<Semester>())
                .Map(this.GetSemesterHistory)
                .Reduce(Enumerable.Empty<Semester>());

        private IEnumerable<Semester> GetSemesterHistory(Semester enrolled) =>
            new List<Semester>(
                enrolled.Predecessor.Map(this.GetSemesterHistory).Reduce(Enumerable.Empty<Semester>()))
                { enrolled };

        public Models.Student ToPersisted(Student model) =>
            new Models.Student()
            {
                FirstName = model.Name.FirstName,
                MiddleNames = model.Name.MiddleNames,
                LastName = model.Name.LastName,
                EnrolledSemester = model.Enrolled.Map(this.SemesterConverter.ToPersisted).Reduce((Models.Semester)null)
            };

        public void CopyChanges(Student from, Models.Student to)
        {
            to.FirstName = from.Name.FirstName;
            to.MiddleNames = from.Name.MiddleNames;
            to.LastName = from.Name.LastName;
        }
    }
}
