﻿using System.Collections.Generic;

namespace Domain.Utils
{
    public static class DictionaryExtensions
    {
        public static Option<TValue> TryGetValue<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key)
        {
            TValue value;
            if (dictionary.TryGetValue(key, out value))
                return Option.Some(value);
            return Option.None<TValue>();
        }
    }
}
