﻿using System;
using Domain.Utils;

namespace Domain.Models
{
    public class Semester
    {
        public Option<Semester> Predecessor { get; }
        public string Label { get; }
        public int Ordinal { get; }

        public Semester(string label, int ordinal)
            : this(Option.None<Semester>(), label, ordinal)
        {
            if (string.IsNullOrEmpty(label))
                throw new ArgumentException();
        }

        public Semester(Semester predecessor, string label, int ordinal)
            : this(Option.Some(predecessor), label, ordinal)
        {
            if (predecessor == null)
                throw new ArgumentNullException(nameof(predecessor));
            if (string.IsNullOrEmpty(label))
                throw new ArgumentException();
        }

        private Semester(Option<Semester> predecessor, string label, int ordinal)
        {
            this.Predecessor = predecessor;
            this.Label = label;
            this.Ordinal = ordinal;
        }
    }
}
