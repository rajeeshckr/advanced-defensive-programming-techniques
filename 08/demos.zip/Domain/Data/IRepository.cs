﻿using System;
using Domain.Utils;

namespace Domain.Data
{
    public interface IRepository<T> : IDisposable
    {
        Option<T> TryFind(int id);
        void Add(T obj);
        void Delete(T obj);
        void SaveChanges();
    }
}
