﻿using System;
using Domain.Data;
using Domain.Models;
using Domain.ViewModels;
using Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Domain.Utils;

namespace College.Controllers
{
    public class StudentsController : Controller
    {
        private IReadOnlyRepository<StudentViewModel> StudentsQueryRepository { get; } =
            ReadOnlyRepositories.CreateStudentRepository();

        private IReadOnlyRepository<SemesterViewModel> SemestersQueryRepository { get; } =
            ReadOnlyRepositories.CreateSemesterRepository();

        private IReadOnlyRepository<LastNamePatternViewModel> NamePatternsQueryRepository { get; } =
            ReadOnlyRepositories.CreateLastNamePatternRepository();

        private IRepository<Student> StudentsRepository { get; } = Repositories.CreateStudentsRepository();

        private IRepository<Semester> SemestersRepository { get; } = Repositories.CreateSemestersRepository();

        public ActionResult Index() =>
            View(this.StudentsQueryRepository.GetAll());

        public ActionResult Details(int id) =>
            this.StudentsQueryRepository
                .TryFind(id)
                .Map(View)
                .Reduce(() => View("Index", this.StudentsQueryRepository.GetAll()));

        public ActionResult Create() => View();

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                return FailIfInvalid(collection).Reduce(() => CreateStudent(collection));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Invalid personal name.");
                return View();
            }
        }

        private Option<ActionResult> FailIfInvalid(FormCollection collection) =>
            FailIfInvalidFirstName(collection["FirstName"]).Map(Option.Some<ActionResult>)
                .Reduce(() => FailIfInvalidMiddleNames(collection["MiddleNames"])).Map(Option.Some<ActionResult>)
                .Reduce(() => FailIfInvalidLastName(collection["LastName"]));

        private ActionResult CreateStudent(FormCollection collection)
        {
            string firstName = collection["FirstName"];
            string middleNames = collection["MiddleNames"];
            string lastName = collection["LastName"];

            IEnumerable<string> lastNamePatterns = this.LoadLastNamePatterns();

            PersonalName name = new PersonalName(lastNamePatterns, firstName, middleNames, lastName);

            Student student = new RegularStudent(name);

            Semester initialSemester = this.GetInitialSemester();
            student.Enroll(initialSemester);

            this.StudentsRepository.Add(student);
            this.StudentsRepository.SaveChanges();

            return RedirectToAction("Index");
        }

        private IEnumerable<string> LoadLastNamePatterns() =>
            this.NamePatternsQueryRepository
                .GetAll()
                .OrderBy(pattern => pattern.Ordinal)
                .Select(pattern => pattern.Value)
                .ToList();

        private Semester GetInitialSemester() =>
            this.SemestersRepository
                .TryFind(this.GetFirstSemesterId())
                .Reduce(() => throw new InvalidOperationException());

        private int GetFirstSemesterId() =>
            this.SemestersQueryRepository
                .GetAll()
                .OrderBy(semester => semester.Ordinal)
                .First()
                .Id;

        private Option<ActionResult> FailIfInvalidFirstName(string value) =>
            this.FailIfNullOrEmpty(value, "FirstName", "First name cannot be empty");

        private Option<ActionResult> FailIfInvalidMiddleNames(string value) =>
            this.FailIfNull(value, "MiddleNames", "Middle names must be defined");

        private Option<ActionResult> FailIfInvalidLastName(string value) =>
            this.FailIfNullOrEmpty(value, "LastName", "Last name cannot be empty");

        private Option<ActionResult> FailIfNullOrEmpty(string value, string modelName, string error) =>
            FailIf(() => string.IsNullOrEmpty(value), modelName, error);

        private Option<ActionResult> FailIfNull(object value, string modelName, string error) =>
            FailIf(() => value == null, modelName, error);

        private Option<ActionResult> FailIf(Func<bool> failCondition, string modelName, string error)
        {
            if (failCondition())
            {
                ModelState.AddModelError(modelName, error);
                return Option.Some<ActionResult>(View("Create"));
            }
            return Option.None<ActionResult>();
        }
    }
}
